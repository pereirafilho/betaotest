const mongoose = require('mongoose');
const { MongoMemoryServer } = require('mongodb-memory-server');

let mongod = null;

// Função para conectar ao banco de dados
const connectDB = async () => {
  try {
    // Verificar se estamos em ambiente de desenvolvimento
    if (process.env.NODE_ENV === 'development' || !process.env.MONGODB_URI) {
      // Usar MongoDB em memória para desenvolvimento
      mongod = await MongoMemoryServer.create();
      const uri = mongod.getUri();
      console.log('Conectando ao MongoDB em memória...');
      
      await mongoose.connect(uri);
      console.log('MongoDB em memória conectado');
    } else {
      // Usar MongoDB real para produção
      await mongoose.connect(process.env.MONGODB_URI);
      console.log('MongoDB conectado');
    }
  } catch (err) {
    console.error('Erro ao conectar ao MongoDB:', err.message);
    process.exit(1);
  }
};

// Função para desconectar do banco de dados
const disconnectDB = async () => {
  try {
    await mongoose.disconnect();
    console.log('MongoDB desconectado');
    
    if (mongod) {
      await mongod.stop();
      console.log('MongoDB em memória parado');
    }
  } catch (err) {
    console.error('Erro ao desconectar do MongoDB:', err.message);
  }
};

// Função para inicializar dados de exemplo
const initializeData = async () => {
  try {
    const TipoBetao = require('../models/TipoBetao');
    const Usuario = require('../models/Usuario');
    const bcrypt = require('bcryptjs');
    
    // Verificar se já existem dados
    const tiposBetaoCount = await TipoBetao.countDocuments();
    const usuariosCount = await Usuario.countDocuments();
    
    if (tiposBetaoCount === 0) {
      console.log('Inicializando tipos de betão...');
      
      // Criar tipos de betão iniciais
      await TipoBetao.create([
        { codigo: 'C20 25.S4.XC2', descricao: 'Betão C20/25, Classe de consistência S4, Classe de exposição XC2' },
        { codigo: 'C25 30.S4.XC2', descricao: 'Betão C25/30, Classe de consistência S4, Classe de exposição XC2' },
        { codigo: 'C35 45.S4.XC3', descricao: 'Betão C35/45, Classe de consistência S4, Classe de exposição XC3' }
      ]);
      
      console.log('Tipos de betão inicializados');
    }
    
    if (usuariosCount === 0) {
      console.log('Inicializando usuário admin...');
      
      // Criar usuário admin
      const salt = await bcrypt.genSalt(10);
      const senhaHash = await bcrypt.hash('admin123', salt);
      
      await Usuario.create({
        nome: 'Administrador',
        email: 'admin@exemplo.com',
        senha: senhaHash,
        cargo: 'Administrador'
      });
      
      console.log('Usuário admin inicializado');
    }
  } catch (err) {
    console.error('Erro ao inicializar dados:', err.message);
  }
};

module.exports = { connectDB, disconnectDB, initializeData };
