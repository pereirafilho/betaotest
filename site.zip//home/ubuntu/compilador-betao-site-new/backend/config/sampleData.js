const mongoose = require('mongoose');
const { MongoMemoryServer } = require('mongodb-memory-server');
const Ensaio = require('../models/Ensaio');
const TipoBetao = require('../models/TipoBetao');
const Usuario = require('../models/Usuario');

// Função para gerar dados de exemplo para testes
const generateSampleData = async () => {
  try {
    console.log('Gerando dados de exemplo para testes...');
    
    // Obter tipos de betão
    const tiposBetao = await TipoBetao.find();
    if (tiposBetao.length === 0) {
      console.error('Nenhum tipo de betão encontrado. Execute initializeData primeiro.');
      return;
    }
    
    // Obter usuário admin
    const admin = await Usuario.findOne({ email: 'admin@exemplo.com' });
    if (!admin) {
      console.error('Usuário admin não encontrado. Execute initializeData primeiro.');
      return;
    }
    
    // Verificar se já existem ensaios
    const ensaiosCount = await Ensaio.countDocuments();
    if (ensaiosCount > 0) {
      console.log('Já existem ensaios no banco de dados. Pulando geração de dados de exemplo.');
      return;
    }
    
    // Gerar datas de fabricação (últimos 3 meses)
    const dataAtual = new Date();
    const datas = [];
    for (let i = 0; i < 90; i++) {
      const data = new Date(dataAtual);
      data.setDate(data.getDate() - i);
      datas.push(data);
    }
    
    // Gerar frentes e elementos
    const frentes = ['Bloco A', 'Bloco B', 'Bloco C', 'Bloco D'];
    const elementos = [
      'Laje Piso 1', 'Laje Piso 2', 'Laje Piso 3',
      'Pilar P1', 'Pilar P2', 'Pilar P3', 'Pilar P4',
      'Viga V1', 'Viga V2', 'Viga V3',
      'Sapata S1', 'Sapata S2', 'Sapata S3'
    ];
    
    // Gerar laboratórios
    const laboratorios = ['BETOTESTE', 'ECLAB', 'SENQUAL'];
    
    // Gerar ensaios
    const ensaios = [];
    
    for (let i = 0; i < 50; i++) {
      // Selecionar tipo de betão aleatório
      const tipoBetao = tiposBetao[Math.floor(Math.random() * tiposBetao.length)];
      
      // Selecionar data de fabricação aleatória
      const dataFabrico = datas[Math.floor(Math.random() * datas.length)];
      
      // Gerar data de ensaio para 7 dias
      const dataEnsaio7d = new Date(dataFabrico);
      dataEnsaio7d.setDate(dataEnsaio7d.getDate() + 7);
      
      // Gerar data de ensaio para 28 dias
      const dataEnsaio28d = new Date(dataFabrico);
      dataEnsaio28d.setDate(dataEnsaio28d.getDate() + 28);
      
      // Gerar valores base para tensão de rotura
      let tensaoBase7d, tensaoBase28d;
      
      if (tipoBetao.codigo.includes('C20')) {
        tensaoBase7d = 15;
        tensaoBase28d = 25;
      } else if (tipoBetao.codigo.includes('C25')) {
        tensaoBase7d = 20;
        tensaoBase28d = 30;
      } else if (tipoBetao.codigo.includes('C35')) {
        tensaoBase7d = 30;
        tensaoBase28d = 45;
      } else {
        tensaoBase7d = 20;
        tensaoBase28d = 30;
      }
      
      // Gerar provetes
      const provetes = [];
      
      // Provetes de 7 dias
      for (let j = 0; j < 3; j++) {
        const variacao = (Math.random() * 10) - 5; // -5% a +5%
        const tensaoRotura = tensaoBase7d * (1 + variacao / 100);
        
        provetes.push({
          numero: j + 1,
          idade: 7,
          dataEnsaio: dataEnsaio7d,
          peso: 8 + (Math.random() * 0.5), // 8.0 a 8.5 kg
          cargaRotura: tensaoRotura * 22.5, // Aproximação para área de 225 cm²
          tensaoRotura: tensaoRotura,
          variacao: Math.abs(variacao)
        });
      }
      
      // Provetes de 28 dias
      for (let j = 0; j < 3; j++) {
        const variacao = (Math.random() * 10) - 5; // -5% a +5%
        const tensaoRotura = tensaoBase28d * (1 + variacao / 100);
        
        provetes.push({
          numero: j + 4,
          idade: 28,
          dataEnsaio: dataEnsaio28d,
          peso: 8 + (Math.random() * 0.5), // 8.0 a 8.5 kg
          cargaRotura: tensaoRotura * 22.5, // Aproximação para área de 225 cm²
          tensaoRotura: tensaoRotura,
          variacao: Math.abs(variacao)
        });
      }
      
      // Calcular médias
      const provetes7d = provetes.filter(p => p.idade === 7);
      const provetes28d = provetes.filter(p => p.idade === 28);
      
      const mediaProvetes7d = provetes7d.reduce((sum, p) => sum + p.tensaoRotura, 0) / provetes7d.length;
      const mediaProvetes28d = provetes28d.reduce((sum, p) => sum + p.tensaoRotura, 0) / provetes28d.length;
      
      // Determinar conformidade (simplificado)
      const conformidade = Math.random() > 0.1; // 90% de chance de ser conforme
      
      // Criar ensaio
      ensaios.push({
        tipoBetaoId: tipoBetao._id,
        frente: frentes[Math.floor(Math.random() * frentes.length)],
        elementoBetonado: elementos[Math.floor(Math.random() * elementos.length)],
        pab: `PAB-${dataFabrico.getFullYear()}-${String(Math.floor(Math.random() * 10000)).padStart(4, '0')}`,
        brb: `BRB-${dataFabrico.getFullYear()}-${String(Math.floor(Math.random() * 10000)).padStart(4, '0')}`,
        guiaRemessa: `GR-${dataFabrico.getFullYear()}-${String(Math.floor(Math.random() * 10000)).padStart(4, '0')}`,
        m3Betonado: Math.floor(Math.random() * 50) + 10, // 10 a 60 m³
        dataFabrico,
        abaixamento: Math.floor(Math.random() * 50) + 100, // 100 a 150 mm
        laboratorio: laboratorios[Math.floor(Math.random() * laboratorios.length)],
        observacoes: 'Ensaio gerado automaticamente para testes.',
        provetes,
        mediaProvetes7d,
        mediaProvetes28d,
        conformidade,
        criadoPor: admin._id
      });
    }
    
    // Salvar ensaios
    await Ensaio.insertMany(ensaios);
    
    console.log(`${ensaios.length} ensaios de exemplo gerados com sucesso.`);
  } catch (err) {
    console.error('Erro ao gerar dados de exemplo:', err.message);
  }
};

module.exports = { generateSampleData };
