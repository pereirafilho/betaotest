const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const ProveteSchema = new Schema({
  numero: {
    type: Number,
    required: true
  },
  idade: {
    type: Number,
    required: true,
    enum: [7, 28]
  },
  dataEnsaio: {
    type: Date,
    required: true
  },
  peso: {
    type: Number,
    required: true
  },
  cargaRotura: {
    type: Number,
    required: true
  },
  tensaoRotura: {
    type: Number,
    required: true
  },
  variacao: {
    type: Number,
    default: 0
  }
});

const EnsaioSchema = new Schema({
  tipoBetaoId: {
    type: Schema.Types.ObjectId,
    ref: 'TipoBetao',
    required: true
  },
  frente: {
    type: String,
    required: true
  },
  elementoBetonado: {
    type: String,
    required: true
  },
  pab: {
    type: String,
    required: true
  },
  brb: {
    type: String,
    required: true
  },
  guiaRemessa: {
    type: String,
    required: true
  },
  m3Betonado: {
    type: Number,
    required: true
  },
  dataFabrico: {
    type: Date,
    required: true
  },
  abaixamento: {
    type: Number,
    required: true
  },
  laboratorio: {
    type: String,
    required: true,
    enum: ['BETOTESTE', 'ECLAB', 'SENQUAL', 'OUTRO']
  },
  observacoes: {
    type: String
  },
  provetes: [ProveteSchema],
  mediaProvetes7d: {
    type: Number
  },
  mediaProvetes28d: {
    type: Number
  },
  conformidade: {
    type: Boolean,
    default: true
  },
  criadoPor: {
    type: Schema.Types.ObjectId,
    ref: 'Usuario',
    required: true
  },
  dataCriacao: {
    type: Date,
    default: Date.now
  }
});

// Middleware para calcular automaticamente as médias e verificar conformidade
EnsaioSchema.pre('save', function(next) {
  // Calcular médias
  const provetes7d = this.provetes.filter(p => p.idade === 7);
  const provetes28d = this.provetes.filter(p => p.idade === 28);
  
  if (provetes7d.length > 0) {
    this.mediaProvetes7d = provetes7d.reduce((sum, p) => sum + p.tensaoRotura, 0) / provetes7d.length;
  }
  
  if (provetes28d.length > 0) {
    this.mediaProvetes28d = provetes28d.reduce((sum, p) => sum + p.tensaoRotura, 0) / provetes28d.length;
  }
  
  // Calcular variações
  this.provetes.forEach(p => {
    const media = p.idade === 7 ? this.mediaProvetes7d : this.mediaProvetes28d;
    if (media) {
      p.variacao = Math.abs((p.tensaoRotura - media) / media * 100);
    }
  });
  
  // Verificar conformidade
  // Implementação simplificada - na prática, a lógica seria mais complexa
  // baseada nos critérios específicos para cada tipo de betão
  const temVariacaoAlta = this.provetes.some(p => p.variacao > 15);
  
  if (temVariacaoAlta) {
    this.conformidade = false;
  }
  
  next();
});

module.exports = mongoose.model('Ensaio', EnsaioSchema);
