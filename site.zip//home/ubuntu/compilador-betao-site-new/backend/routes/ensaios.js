const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');
const Ensaio = require('../models/Ensaio');
const { processarDadosEnsaio } = require('../utils/ensaioUtils');

// Middleware para processar dados de ensaio
const processarEnsaio = async (req, res, next) => {
  try {
    // Processar dados do ensaio
    req.dadosProcessados = await processarDadosEnsaio({
      ...req.body,
      criadoPor: req.usuario.id
    });
    next();
  } catch (err) {
    console.error('Erro ao processar dados de ensaio:', err.message);
    return res.status(500).json({ msg: 'Erro ao processar dados de ensaio' });
  }
};

// @route   POST api/ensaios
// @desc    Criar um novo ensaio
// @access  Private
router.post('/', auth, processarEnsaio, async (req, res) => {
  try {
    // Criar novo ensaio
    const novoEnsaio = new Ensaio(req.dadosProcessados);
    const ensaio = await novoEnsaio.save();
    
    res.json(ensaio);
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Erro no servidor');
  }
});

// @route   PUT api/ensaios/:id
// @desc    Atualizar um ensaio
// @access  Private
router.put('/:id', auth, processarEnsaio, async (req, res) => {
  try {
    let ensaio = await Ensaio.findById(req.params.id);
    
    if (!ensaio) {
      return res.status(404).json({ msg: 'Ensaio não encontrado' });
    }

    // Verificar se o usuário é o criador do ensaio
    if (ensaio.criadoPor.toString() !== req.usuario.id) {
      return res.status(401).json({ msg: 'Não autorizado' });
    }
    
    // Atualizar ensaio
    ensaio = await Ensaio.findByIdAndUpdate(
      req.params.id,
      { $set: req.dadosProcessados },
      { new: true }
    );
    
    res.json(ensaio);
  } catch (err) {
    console.error(err.message);
    if (err.kind === 'ObjectId') {
      return res.status(404).json({ msg: 'Ensaio não encontrado' });
    }
    res.status(500).send('Erro no servidor');
  }
});

// @route   GET api/ensaios
// @desc    Obter todos os ensaios
// @access  Private
router.get('/', auth, async (req, res) => {
  try {
    const ensaios = await Ensaio.find()
      .populate('tipoBetaoId', 'codigo')
      .populate('criadoPor', 'nome')
      .sort({ dataCriacao: -1 });
    res.json(ensaios);
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Erro no servidor');
  }
});

// @route   GET api/ensaios/:id
// @desc    Obter ensaio por ID
// @access  Private
router.get('/:id', auth, async (req, res) => {
  try {
    const ensaio = await Ensaio.findById(req.params.id)
      .populate('tipoBetaoId', 'codigo descricao')
      .populate('criadoPor', 'nome');
    
    if (!ensaio) {
      return res.status(404).json({ msg: 'Ensaio não encontrado' });
    }
    
    res.json(ensaio);
  } catch (err) {
    console.error(err.message);
    if (err.kind === 'ObjectId') {
      return res.status(404).json({ msg: 'Ensaio não encontrado' });
    }
    res.status(500).send('Erro no servidor');
  }
});

// @route   DELETE api/ensaios/:id
// @desc    Excluir um ensaio
// @access  Private
router.delete('/:id', auth, async (req, res) => {
  try {
    const ensaio = await Ensaio.findById(req.params.id);
    
    if (!ensaio) {
      return res.status(404).json({ msg: 'Ensaio não encontrado' });
    }

    // Verificar se o usuário é o criador do ensaio
    if (ensaio.criadoPor.toString() !== req.usuario.id) {
      return res.status(401).json({ msg: 'Não autorizado' });
    }

    await ensaio.remove();
    res.json({ msg: 'Ensaio removido' });
  } catch (err) {
    console.error(err.message);
    if (err.kind === 'ObjectId') {
      return res.status(404).json({ msg: 'Ensaio não encontrado' });
    }
    res.status(500).send('Erro no servidor');
  }
});

// @route   GET api/ensaios/tipo/:tipoBetaoId
// @desc    Obter ensaios por tipo de betão
// @access  Private
router.get('/tipo/:tipoBetaoId', auth, async (req, res) => {
  try {
    const ensaios = await Ensaio.find({ tipoBetaoId: req.params.tipoBetaoId })
      .populate('tipoBetaoId', 'codigo')
      .populate('criadoPor', 'nome')
      .sort({ dataCriacao: -1 });
    
    res.json(ensaios);
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Erro no servidor');
  }
});

// @route   GET api/ensaios/conformidade/:status
// @desc    Obter ensaios por status de conformidade
// @access  Private
router.get('/conformidade/:status', auth, async (req, res) => {
  try {
    const conformidade = req.params.status === 'conforme';
    
    const ensaios = await Ensaio.find({ conformidade })
      .populate('tipoBetaoId', 'codigo')
      .populate('criadoPor', 'nome')
      .sort({ dataCriacao: -1 });
    
    res.json(ensaios);
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Erro no servidor');
  }
});

module.exports = router;
