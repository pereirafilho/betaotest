const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');
const Ensaio = require('../models/Ensaio');
const TipoBetao = require('../models/TipoBetao');
const { calcularTensaoRuptura } = require('../utils/ensaioUtils');

// @route   POST api/relatorios/exportar
// @desc    Exportar dados para formato CSV
// @access  Private
router.post('/exportar', auth, async (req, res) => {
  try {
    const { tipoRelatorio, tipoBetaoId, dataInicio, dataFim } = req.body;
    
    // Construir filtro
    const filtro = {};
    
    if (tipoBetaoId) {
      filtro.tipoBetaoId = tipoBetaoId;
    }
    
    if (dataInicio || dataFim) {
      filtro.dataFabrico = {};
      
      if (dataInicio) {
        filtro.dataFabrico.$gte = new Date(dataInicio);
      }
      
      if (dataFim) {
        filtro.dataFabrico.$lte = new Date(dataFim);
      }
    }
    
    // Buscar dados
    const ensaios = await Ensaio.find(filtro)
      .populate('tipoBetaoId', 'codigo')
      .populate('criadoPor', 'nome')
      .sort({ dataFabrico: -1 });
    
    // Gerar CSV
    let csv = '';
    
    if (tipoRelatorio === 'completo') {
      // Cabeçalho
      csv = 'Data Fabrico,Tipo Betão,Frente,Elemento Betonado,PAB,BRB,Guia Remessa,M3 Betonado,Abaixamento,Laboratório,Média 7d,Média 28d,Conformidade\n';
      
      // Dados
      ensaios.forEach(ensaio => {
        const dataFabrico = ensaio.dataFabrico ? new Date(ensaio.dataFabrico).toLocaleDateString('pt-BR') : '';
        const tipoBetao = ensaio.tipoBetaoId ? ensaio.tipoBetaoId.codigo : '';
        const media7d = ensaio.mediaProvetes7d ? ensaio.mediaProvetes7d.toFixed(1) : '';
        const media28d = ensaio.mediaProvetes28d ? ensaio.mediaProvetes28d.toFixed(1) : '';
        const conformidade = ensaio.conformidade ? 'Conforme' : 'Não Conforme';
        
        csv += `${dataFabrico},${tipoBetao},${ensaio.frente},${ensaio.elementoBetonado},${ensaio.pab},${ensaio.brb},${ensaio.guiaRemessa},${ensaio.m3Betonado},${ensaio.abaixamento},${ensaio.laboratorio},${media7d},${media28d},${conformidade}\n`;
      });
    } else if (tipoRelatorio === 'resumido') {
      // Agrupar por tipo de betão
      const tiposBetao = await TipoBetao.find();
      
      // Cabeçalho
      csv = 'Tipo Betão,Total Ensaios,Ensaios Conformes,Ensaios Não Conformes,Taxa Conformidade,Média 7d,Média 28d\n';
      
      // Dados
      for (const tipo of tiposBetao) {
        const ensaiosTipo = ensaios.filter(e => e.tipoBetaoId && e.tipoBetaoId._id.toString() === tipo._id.toString());
        
        if (ensaiosTipo.length === 0) continue;
        
        const totalEnsaios = ensaiosTipo.length;
        const ensaiosConformes = ensaiosTipo.filter(e => e.conformidade).length;
        const ensaiosNaoConformes = totalEnsaios - ensaiosConformes;
        const taxaConformidade = totalEnsaios > 0 ? ((ensaiosConformes / totalEnsaios) * 100).toFixed(1) : '100.0';
        
        // Calcular médias
        let soma7d = 0;
        let count7d = 0;
        let soma28d = 0;
        let count28d = 0;
        
        ensaiosTipo.forEach(ensaio => {
          if (ensaio.mediaProvetes7d) {
            soma7d += ensaio.mediaProvetes7d;
            count7d++;
          }
          
          if (ensaio.mediaProvetes28d) {
            soma28d += ensaio.mediaProvetes28d;
            count28d++;
          }
        });
        
        const media7d = count7d > 0 ? (soma7d / count7d).toFixed(1) : '';
        const media28d = count28d > 0 ? (soma28d / count28d).toFixed(1) : '';
        
        csv += `${tipo.codigo},${totalEnsaios},${ensaiosConformes},${ensaiosNaoConformes},${taxaConformidade}%,${media7d},${media28d}\n`;
      }
    } else if (tipoRelatorio === 'provetes') {
      // Cabeçalho
      csv = 'Data Fabrico,Tipo Betão,Elemento Betonado,Provete,Idade,Data Ensaio,Peso,Carga Rotura,Tensão Rotura,Variação\n';
      
      // Dados
      ensaios.forEach(ensaio => {
        const dataFabrico = ensaio.dataFabrico ? new Date(ensaio.dataFabrico).toLocaleDateString('pt-BR') : '';
        const tipoBetao = ensaio.tipoBetaoId ? ensaio.tipoBetaoId.codigo : '';
        
        ensaio.provetes.forEach(provete => {
          const dataEnsaio = provete.dataEnsaio ? new Date(provete.dataEnsaio).toLocaleDateString('pt-BR') : '';
          
          csv += `${dataFabrico},${tipoBetao},${ensaio.elementoBetonado},${provete.numero},${provete.idade},${dataEnsaio},${provete.peso},${provete.cargaRotura},${provete.tensaoRotura.toFixed(1)},${provete.variacao.toFixed(1)}%\n`;
        });
      });
    }
    
    // Enviar CSV
    res.setHeader('Content-Type', 'text/csv');
    res.setHeader('Content-Disposition', `attachment; filename=relatorio-${tipoRelatorio}-${new Date().toISOString().split('T')[0]}.csv`);
    res.send(csv);
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Erro no servidor');
  }
});

// Manter as outras rotas existentes...
// @route   GET api/relatorios/resumo
// @desc    Obter resumo geral de todos os ensaios
// @access  Private
router.get('/resumo', auth, async (req, res) => {
  try {
    // Total de ensaios
    const totalEnsaios = await Ensaio.countDocuments();
    
    // Ensaios conformes e não conformes
    const ensaiosConformes = await Ensaio.countDocuments({ conformidade: true });
    const ensaiosNaoConformes = await Ensaio.countDocuments({ conformidade: false });
    
    // Distribuição por tipo de betão
    const tiposBetao = await TipoBetao.find();
    const distribuicaoPorTipo = [];
    
    for (const tipo of tiposBetao) {
      const count = await Ensaio.countDocuments({ tipoBetaoId: tipo._id });
      distribuicaoPorTipo.push({
        tipo: tipo.codigo,
        quantidade: count
      });
    }
    
    // Média de resistência por tipo de betão
    const mediasPorTipo = [];
    
    for (const tipo of tiposBetao) {
      const ensaios = await Ensaio.find({ tipoBetaoId: tipo._id });
      
      let soma7d = 0;
      let count7d = 0;
      let soma28d = 0;
      let count28d = 0;
      
      ensaios.forEach(ensaio => {
        if (ensaio.mediaProvetes7d) {
          soma7d += ensaio.mediaProvetes7d;
          count7d++;
        }
        
        if (ensaio.mediaProvetes28d) {
          soma28d += ensaio.mediaProvetes28d;
          count28d++;
        }
      });
      
      mediasPorTipo.push({
        tipo: tipo.codigo,
        media7d: count7d > 0 ? soma7d / count7d : null,
        media28d: count28d > 0 ? soma28d / count28d : null
      });
    }
    
    res.json({
      totalEnsaios,
      ensaiosConformes,
      ensaiosNaoConformes,
      distribuicaoPorTipo,
      mediasPorTipo
    });
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Erro no servidor');
  }
});

// @route   GET api/relatorios/tipo-betao/:id
// @desc    Obter relatório detalhado por tipo de betão
// @access  Private
router.get('/tipo-betao/:id', auth, async (req, res) => {
  try {
    const tipoBetao = await TipoBetao.findById(req.params.id);
    
    if (!tipoBetao) {
      return res.status(404).json({ msg: 'Tipo de betão não encontrado' });
    }
    
    const ensaios = await Ensaio.find({ tipoBetaoId: req.params.id })
      .populate('criadoPor', 'nome')
      .sort({ dataFabrico: -1 });
    
    // Total de ensaios
    const totalEnsaios = ensaios.length;
    
    // Ensaios conformes e não conformes
    const ensaiosConformes = ensaios.filter(e => e.conformidade).length;
    const ensaiosNaoConformes = ensaios.filter(e => !e.conformidade).length;
    
    // Médias de resistência
    let soma7d = 0;
    let count7d = 0;
    let soma28d = 0;
    let count28d = 0;
    
    ensaios.forEach(ensaio => {
      if (ensaio.mediaProvetes7d) {
        soma7d += ensaio.mediaProvetes7d;
        count7d++;
      }
      
      if (ensaio.mediaProvetes28d) {
        soma28d += ensaio.mediaProvetes28d;
        count28d++;
      }
    });
    
    const media7d = count7d > 0 ? soma7d / count7d : null;
    const media28d = count28d > 0 ? soma28d / count28d : null;
    
    res.json({
      tipoBetao,
      totalEnsaios,
      ensaiosConformes,
      ensaiosNaoConformes,
      media7d,
      media28d,
      ensaios
    });
  } catch (err) {
    console.error(err.message);
    if (err.kind === 'ObjectId') {
      return res.status(404).json({ msg: 'Tipo de betão não encontrado' });
    }
    res.status(500).send('Erro no servidor');
  }
});

// @route   GET api/relatorios/conformidade
// @desc    Obter relatório de conformidade
// @access  Private
router.get('/conformidade', auth, async (req, res) => {
  try {
    const ensaiosNaoConformes = await Ensaio.find({ conformidade: false })
      .populate('tipoBetaoId', 'codigo')
      .populate('criadoPor', 'nome')
      .sort({ dataFabrico: -1 });
    
    // Agrupamento por tipo de betão
    const tiposBetao = await TipoBetao.find();
    const distribuicaoPorTipo = [];
    
    for (const tipo of tiposBetao) {
      const totalEnsaios = await Ensaio.countDocuments({ tipoBetaoId: tipo._id });
      const naoConformes = await Ensaio.countDocuments({ 
        tipoBetaoId: tipo._id,
        conformidade: false
      });
      
      distribuicaoPorTipo.push({
        tipo: tipo.codigo,
        totalEnsaios,
        naoConformes,
        taxaConformidade: totalEnsaios > 0 ? ((totalEnsaios - naoConformes) / totalEnsaios) * 100 : 100
      });
    }
    
    res.json({
      distribuicaoPorTipo,
      ensaiosNaoConformes
    });
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Erro no servidor');
  }
});

// @route   GET api/relatorios/evolucao
// @desc    Obter relatório de evolução temporal
// @access  Private
router.get('/evolucao', auth, async (req, res) => {
  try {
    const ensaios = await Ensaio.find()
      .populate('tipoBetaoId', 'codigo')
      .sort({ dataFabrico: 1 });
    
    // Agrupar por mês
    const evolucaoMensal = {};
    
    ensaios.forEach(ensaio => {
      const data = new Date(ensaio.dataFabrico);
      const mes = `${data.getFullYear()}-${String(data.getMonth() + 1).padStart(2, '0')}`;
      
      if (!evolucaoMensal[mes]) {
        evolucaoMensal[mes] = {
          totalEnsaios: 0,
          ensaiosConformes: 0,
          ensaiosNaoConformes: 0,
          media7d: { soma: 0, count: 0 },
          media28d: { soma: 0, count: 0 }
        };
      }
      
      evolucaoMensal[mes].totalEnsaios++;
      
      if (ensaio.conformidade) {
        evolucaoMensal[mes].ensaiosConformes++;
      } else {
        evolucaoMensal[mes].ensaiosNaoConformes++;
      }
      
      if (ensaio.mediaProvetes7d) {
        evolucaoMensal[mes].media7d.soma += ensaio.mediaProvetes7d;
        evolucaoMensal[mes].media7d.count++;
      }
      
      if (ensaio.mediaProvetes28d) {
        evolucaoMensal[mes].media28d.soma += ensaio.mediaProvetes28d;
        evolucaoMensal[mes].media28d.count++;
      }
    });
    
    // Calcular médias finais
    const evolucao = Object.keys(evolucaoMensal).map(mes => {
      const dados = evolucaoMensal[mes];
      return {
        mes,
        totalEnsaios: dados.totalEnsaios,
        ensaiosConformes: dados.ensaiosConformes,
        ensaiosNaoConformes: dados.ensaiosNaoConformes,
        taxaConformidade: dados.totalEnsaios > 0 ? (dados.ensaiosConformes / dados.totalEnsaios) * 100 : 100,
        media7d: dados.media7d.count > 0 ? dados.media7d.soma / dados.media7d.count : null,
        media28d: dados.media28d.count > 0 ? dados.media28d.soma / dados.media28d.count : null
      };
    });
    
    res.json(evolucao);
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Erro no servidor');
  }
});

module.exports = router;
