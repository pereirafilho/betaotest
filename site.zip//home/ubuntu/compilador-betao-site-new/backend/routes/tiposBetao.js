const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');
const TipoBetao = require('../models/TipoBetao');

// @route   GET api/tipos-betao
// @desc    Obter todos os tipos de betão
// @access  Private
router.get('/', auth, async (req, res) => {
  try {
    const tiposBetao = await TipoBetao.find().sort({ codigo: 1 });
    res.json(tiposBetao);
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Erro no servidor');
  }
});

// @route   GET api/tipos-betao/:id
// @desc    Obter tipo de betão por ID
// @access  Private
router.get('/:id', auth, async (req, res) => {
  try {
    const tipoBetao = await TipoBetao.findById(req.params.id);
    
    if (!tipoBetao) {
      return res.status(404).json({ msg: 'Tipo de betão não encontrado' });
    }
    
    res.json(tipoBetao);
  } catch (err) {
    console.error(err.message);
    if (err.kind === 'ObjectId') {
      return res.status(404).json({ msg: 'Tipo de betão não encontrado' });
    }
    res.status(500).send('Erro no servidor');
  }
});

// @route   POST api/tipos-betao
// @desc    Criar um novo tipo de betão
// @access  Private
router.post('/', auth, async (req, res) => {
  const { codigo, descricao } = req.body;

  try {
    // Verificar se o tipo de betão já existe
    let tipoBetao = await TipoBetao.findOne({ codigo });
    if (tipoBetao) {
      return res.status(400).json({ msg: 'Tipo de betão já existe' });
    }

    // Criar novo tipo de betão
    tipoBetao = new TipoBetao({
      codigo,
      descricao
    });

    await tipoBetao.save();
    res.json(tipoBetao);
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Erro no servidor');
  }
});

// @route   PUT api/tipos-betao/:id
// @desc    Atualizar um tipo de betão
// @access  Private
router.put('/:id', auth, async (req, res) => {
  const { codigo, descricao } = req.body;

  try {
    let tipoBetao = await TipoBetao.findById(req.params.id);
    
    if (!tipoBetao) {
      return res.status(404).json({ msg: 'Tipo de betão não encontrado' });
    }

    // Atualizar campos
    if (codigo) tipoBetao.codigo = codigo;
    if (descricao) tipoBetao.descricao = descricao;

    await tipoBetao.save();
    res.json(tipoBetao);
  } catch (err) {
    console.error(err.message);
    if (err.kind === 'ObjectId') {
      return res.status(404).json({ msg: 'Tipo de betão não encontrado' });
    }
    res.status(500).send('Erro no servidor');
  }
});

// @route   DELETE api/tipos-betao/:id
// @desc    Excluir um tipo de betão
// @access  Private
router.delete('/:id', auth, async (req, res) => {
  try {
    const tipoBetao = await TipoBetao.findById(req.params.id);
    
    if (!tipoBetao) {
      return res.status(404).json({ msg: 'Tipo de betão não encontrado' });
    }

    await tipoBetao.remove();
    res.json({ msg: 'Tipo de betão removido' });
  } catch (err) {
    console.error(err.message);
    if (err.kind === 'ObjectId') {
      return res.status(404).json({ msg: 'Tipo de betão não encontrado' });
    }
    res.status(500).send('Erro no servidor');
  }
});

module.exports = router;
