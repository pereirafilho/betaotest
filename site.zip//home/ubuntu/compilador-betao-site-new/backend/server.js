require('dotenv').config();
const express = require('express');
const { connectDB, initializeData } = require('./config/db');
const { generateSampleData } = require('./config/sampleData');
const cors = require('cors');

// Inicializar app Express
const app = express();

// Middleware
app.use(cors());
app.use(express.json());

// Conectar ao banco de dados
connectDB()
  .then(() => {
    // Inicializar dados básicos
    return initializeData();
  })
  .then(() => {
    // Gerar dados de exemplo para testes
    return generateSampleData();
  })
  .then(() => {
    console.log('Banco de dados inicializado com sucesso');
  })
  .catch(err => {
    console.error('Erro ao inicializar banco de dados:', err.message);
  });

// Rotas
const authRoutes = require('./routes/auth');
const ensaiosRoutes = require('./routes/ensaios');
const tiposBetaoRoutes = require('./routes/tiposBetao');
const relatoriosRoutes = require('./routes/relatorios');

app.use('/api/auth', authRoutes);
app.use('/api/ensaios', ensaiosRoutes);
app.use('/api/tipos-betao', tiposBetaoRoutes);
app.use('/api/relatorios', relatoriosRoutes);

// Rota de teste
app.get('/', (req, res) => {
  res.json({ message: 'API do Compilador Betão funcionando!' });
});

// Iniciar servidor
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`Servidor rodando na porta ${PORT}`);
});
