const mongoose = require('mongoose');
const Ensaio = require('../models/Ensaio');
const TipoBetao = require('../models/TipoBetao');

// Função para calcular a tensão de ruptura com base na carga e área
const calcularTensaoRuptura = (cargaRotura, secao = 225) => {
  return parseFloat((cargaRotura / secao).toFixed(1));
};

// Função para calcular a data de ensaio com base na data de fabricação e idade
const calcularDataEnsaio = (dataFabrico, idade) => {
  const dataEnsaio = new Date(dataFabrico);
  dataEnsaio.setDate(dataEnsaio.getDate() + idade);
  return dataEnsaio;
};

// Função para verificar conformidade do ensaio
const verificarConformidade = (provetes, tipoBetao) => {
  // Agrupar provetes por idade
  const provetesPorIdade = {};
  provetes.forEach(p => {
    if (!provetesPorIdade[p.idade]) {
      provetesPorIdade[p.idade] = [];
    }
    provetesPorIdade[p.idade].push(p);
  });
  
  // Verificar conformidade para cada grupo de idade
  let conformidadeGeral = true;
  
  Object.keys(provetesPorIdade).forEach(idade => {
    const provetesGrupo = provetesPorIdade[idade];
    
    // Calcular média do grupo
    const media = provetesGrupo.reduce((sum, p) => sum + p.tensaoRotura, 0) / provetesGrupo.length;
    
    // Verificar variação individual (critério 1)
    const temVariacaoAlta = provetesGrupo.some(p => {
      const variacao = Math.abs((p.tensaoRotura - media) / media * 100);
      return variacao > 15;
    });
    
    // Verificar resistência mínima (critério 2)
    let resistenciaMinima;
    if (tipoBetao.codigo.includes('C20')) {
      resistenciaMinima = 20;
    } else if (tipoBetao.codigo.includes('C25')) {
      resistenciaMinima = 25;
    } else if (tipoBetao.codigo.includes('C35')) {
      resistenciaMinima = 35;
    } else {
      resistenciaMinima = 25; // Valor padrão
    }
    
    // Para idade de 7 dias, a resistência mínima é aproximadamente 70% da resistência aos 28 dias
    if (parseInt(idade) === 7) {
      resistenciaMinima = resistenciaMinima * 0.7;
    }
    
    const temResistenciaBaixa = provetesGrupo.some(p => p.tensaoRotura < (resistenciaMinima - 4));
    
    // Verificar média (critério 3)
    let mediaMinima;
    if (provetesGrupo.length >= 1 && provetesGrupo.length <= 4) {
      mediaMinima = resistenciaMinima + 1;
    } else if (provetesGrupo.length >= 5 && provetesGrupo.length <= 6) {
      mediaMinima = resistenciaMinima + 2;
    } else {
      mediaMinima = resistenciaMinima;
    }
    
    const temMediaBaixa = media < mediaMinima;
    
    // Atualizar conformidade geral
    if (temVariacaoAlta || temResistenciaBaixa || temMediaBaixa) {
      conformidadeGeral = false;
    }
  });
  
  return conformidadeGeral;
};

// Função para processar dados de ensaio
const processarDadosEnsaio = async (dadosEnsaio) => {
  try {
    // Obter tipo de betão
    const tipoBetao = await TipoBetao.findById(dadosEnsaio.tipoBetaoId);
    if (!tipoBetao) {
      throw new Error('Tipo de betão não encontrado');
    }
    
    // Processar provetes
    const provetes = dadosEnsaio.provetes.map(p => {
      // Calcular tensão de ruptura se não fornecida
      if (!p.tensaoRotura && p.cargaRotura) {
        p.tensaoRotura = calcularTensaoRuptura(p.cargaRotura);
      }
      
      // Calcular data de ensaio se não fornecida
      if (!p.dataEnsaio && dadosEnsaio.dataFabrico && p.idade) {
        p.dataEnsaio = calcularDataEnsaio(dadosEnsaio.dataFabrico, p.idade);
      }
      
      return p;
    });
    
    // Calcular médias
    const provetes7d = provetes.filter(p => p.idade === 7);
    const provetes28d = provetes.filter(p => p.idade === 28);
    
    let mediaProvetes7d = null;
    let mediaProvetes28d = null;
    
    if (provetes7d.length > 0) {
      mediaProvetes7d = provetes7d.reduce((sum, p) => sum + p.tensaoRotura, 0) / provetes7d.length;
    }
    
    if (provetes28d.length > 0) {
      mediaProvetes28d = provetes28d.reduce((sum, p) => sum + p.tensaoRotura, 0) / provetes28d.length;
    }
    
    // Calcular variações
    provetes.forEach(p => {
      const media = p.idade === 7 ? mediaProvetes7d : mediaProvetes28d;
      if (media) {
        p.variacao = parseFloat((Math.abs((p.tensaoRotura - media) / media * 100)).toFixed(1));
      }
    });
    
    // Verificar conformidade
    const conformidade = verificarConformidade(provetes, tipoBetao);
    
    // Retornar dados processados
    return {
      ...dadosEnsaio,
      provetes,
      mediaProvetes7d,
      mediaProvetes28d,
      conformidade
    };
  } catch (err) {
    console.error('Erro ao processar dados de ensaio:', err.message);
    throw err;
  }
};

module.exports = {
  calcularTensaoRuptura,
  calcularDataEnsaio,
  verificarConformidade,
  processarDadosEnsaio
};
