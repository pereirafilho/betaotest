import { FC } from 'react';
import Link from 'next/link';

const Sidebar: FC = () => {
  return (
    <div className="bg-gray-800 text-white w-64 min-h-screen p-4">
      <div className="mb-8">
        <h2 className="text-xl font-bold mb-5">Menu</h2>
        <ul className="space-y-2">
          <li>
            <Link href="/dashboard" className="block py-2 px-4 rounded hover:bg-gray-700">
              Dashboard
            </Link>
          </li>
          <li>
            <Link href="/ensaios" className="block py-2 px-4 rounded hover:bg-gray-700">
              Ensaios
            </Link>
          </li>
          <li>
            <Link href="/formulario" className="block py-2 px-4 rounded hover:bg-gray-700">
              Novo Ensaio
            </Link>
          </li>
          <li>
            <Link href="/relatorios" className="block py-2 px-4 rounded hover:bg-gray-700">
              Relatórios
            </Link>
          </li>
        </ul>
      </div>
      <div>
        <h2 className="text-xl font-bold mb-5">Tipos de Betão</h2>
        <ul className="space-y-2">
          <li>
            <Link href="/ensaios/tipo/1" className="block py-2 px-4 rounded hover:bg-gray-700">
              C20 25.S4.XC2
            </Link>
          </li>
          <li>
            <Link href="/ensaios/tipo/2" className="block py-2 px-4 rounded hover:bg-gray-700">
              C25 30.S4.XC2
            </Link>
          </li>
          <li>
            <Link href="/ensaios/tipo/3" className="block py-2 px-4 rounded hover:bg-gray-700">
              C35 45.S4.XC3
            </Link>
          </li>
        </ul>
      </div>
    </div>
  );
};

export default Sidebar;
