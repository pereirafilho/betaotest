import { FC } from 'react';
import MainLayout from '../components/layout/MainLayout';

const DashboardPage: FC = () => {
  return (
    <MainLayout>
      <div className="bg-white shadow rounded-lg p-6">
        <h1 className="text-2xl font-bold text-gray-800 mb-6">Dashboard</h1>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
            <h2 className="text-sm font-medium text-blue-800 uppercase tracking-wider">Total de Ensaios</h2>
            <p className="mt-2 text-3xl font-bold text-blue-900">157</p>
            <p className="mt-1 text-sm text-blue-600">Desde o início</p>
          </div>
          
          <div className="bg-green-50 p-4 rounded-lg border border-green-200">
            <h2 className="text-sm font-medium text-green-800 uppercase tracking-wider">Ensaios Conformes</h2>
            <p className="mt-2 text-3xl font-bold text-green-900">142</p>
            <p className="mt-1 text-sm text-green-600">90.4% do total</p>
          </div>
          
          <div className="bg-red-50 p-4 rounded-lg border border-red-200">
            <h2 className="text-sm font-medium text-red-800 uppercase tracking-wider">Ensaios Não Conformes</h2>
            <p className="mt-2 text-3xl font-bold text-red-900">15</p>
            <p className="mt-1 text-sm text-red-600">9.6% do total</p>
          </div>
          
          <div className="bg-purple-50 p-4 rounded-lg border border-purple-200">
            <h2 className="text-sm font-medium text-purple-800 uppercase tracking-wider">Ensaios este Mês</h2>
            <p className="mt-2 text-3xl font-bold text-purple-900">23</p>
            <p className="mt-1 text-sm text-purple-600">+15% que mês anterior</p>
          </div>
        </div>
        
        <div className="mb-8">
          <h2 className="text-lg font-semibold text-gray-800 mb-4">Distribuição por Tipo de Betão</h2>
          <div className="bg-gray-50 p-4 rounded-lg border border-gray-200">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="bg-white p-3 rounded-md border border-gray-200">
                <h3 className="text-sm font-medium text-gray-500">C20 25.S4.XC2</h3>
                <p className="mt-1 text-xl font-semibold text-gray-900">52 ensaios</p>
                <div className="mt-2 w-full bg-gray-200 rounded-full h-2.5">
                  <div className="bg-blue-600 h-2.5 rounded-full" style={{ width: '33%' }}></div>
                </div>
              </div>
              
              <div className="bg-white p-3 rounded-md border border-gray-200">
                <h3 className="text-sm font-medium text-gray-500">C25 30.S4.XC2</h3>
                <p className="mt-1 text-xl font-semibold text-gray-900">78 ensaios</p>
                <div className="mt-2 w-full bg-gray-200 rounded-full h-2.5">
                  <div className="bg-green-600 h-2.5 rounded-full" style={{ width: '50%' }}></div>
                </div>
              </div>
              
              <div className="bg-white p-3 rounded-md border border-gray-200">
                <h3 className="text-sm font-medium text-gray-500">C35 45.S4.XC3</h3>
                <p className="mt-1 text-xl font-semibold text-gray-900">27 ensaios</p>
                <div className="mt-2 w-full bg-gray-200 rounded-full h-2.5">
                  <div className="bg-purple-600 h-2.5 rounded-full" style={{ width: '17%' }}></div>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        <div className="mb-8">
          <h2 className="text-lg font-semibold text-gray-800 mb-4">Últimos Ensaios</h2>
          <div className="bg-gray-50 p-4 rounded-lg border border-gray-200 overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-100">
                <tr>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Data</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Tipo Betão</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Elemento</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Média 28d</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                <tr>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">25/03/2025</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">C25 30.S4.XC2</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">Laje Piso 3</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">32.4 MPa</td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">Conforme</span>
                  </td>
                </tr>
                <tr>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">24/03/2025</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">C35 45.S4.XC3</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">Pilar P2</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">47.2 MPa</td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">Conforme</span>
                  </td>
                </tr>
                <tr>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">23/03/2025</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">C20 25.S4.XC2</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">Sapata S1</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">18.7 MPa</td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-red-100 text-red-800">Não Conforme</span>
                  </td>
                </tr>
                <tr>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">22/03/2025</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">C25 30.S4.XC2</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">Viga V3</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">31.8 MPa</td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">Conforme</span>
                  </td>
                </tr>
                <tr>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">21/03/2025</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">C25 30.S4.XC2</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">Laje Piso 2</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">30.5 MPa</td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">Conforme</span>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </MainLayout>
  );
};

export default DashboardPage;
