import { FC } from 'react';
import Link from 'next/link';
import MainLayout from '../../components/layout/MainLayout';

const EnsaioDetalhePage: FC = () => {
  return (
    <MainLayout>
      <div className="bg-white shadow rounded-lg p-6">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-2xl font-bold text-gray-800">Detalhes do Ensaio</h1>
          <div className="flex space-x-2">
            <Link 
              href="/ensaios" 
              className="inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50"
            >
              Voltar para Ensaios
            </Link>
          </div>
        </div>
        
        <div className="mb-8">
          <h2 className="text-lg font-semibold text-gray-700 mb-4">Informações Gerais</h2>
          <div className="bg-gray-50 p-4 rounded-lg border border-gray-200">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              <div>
                <p className="text-sm font-medium text-gray-500">Tipo de Betão</p>
                <p className="mt-1 text-sm text-gray-900">C25 30.S4.XC2</p>
              </div>
              <div>
                <p className="text-sm font-medium text-gray-500">Frente / Localização</p>
                <p className="mt-1 text-sm text-gray-900">Bloco A</p>
              </div>
              <div>
                <p className="text-sm font-medium text-gray-500">Elemento Betonado / Fase</p>
                <p className="mt-1 text-sm text-gray-900">Laje Piso 3</p>
              </div>
              <div>
                <p className="text-sm font-medium text-gray-500">PAB</p>
                <p className="mt-1 text-sm text-gray-900">PAB-2025-0123</p>
              </div>
              <div>
                <p className="text-sm font-medium text-gray-500">BRB</p>
                <p className="mt-1 text-sm text-gray-900">BRB-2025-0456</p>
              </div>
              <div>
                <p className="text-sm font-medium text-gray-500">Guia de Remessa</p>
                <p className="mt-1 text-sm text-gray-900">GR-2025-0789</p>
              </div>
              <div>
                <p className="text-sm font-medium text-gray-500">M3 Betonado</p>
                <p className="mt-1 text-sm text-gray-900">45.5</p>
              </div>
              <div>
                <p className="text-sm font-medium text-gray-500">Data de Fabrico</p>
                <p className="mt-1 text-sm text-gray-900">25/03/2025</p>
              </div>
              <div>
                <p className="text-sm font-medium text-gray-500">Abaixamento (mm)</p>
                <p className="mt-1 text-sm text-gray-900">120</p>
              </div>
              <div>
                <p className="text-sm font-medium text-gray-500">Laboratório Ensaio</p>
                <p className="mt-1 text-sm text-gray-900">BETOTESTE</p>
              </div>
              <div className="md:col-span-2 lg:col-span-3">
                <p className="text-sm font-medium text-gray-500">Observações</p>
                <p className="mt-1 text-sm text-gray-900">Ensaio realizado em condições normais. Betão apresentou boa trabalhabilidade.</p>
              </div>
            </div>
          </div>
        </div>
        
        <div className="mb-8">
          <h2 className="text-lg font-semibold text-gray-700 mb-4">Resultados dos Ensaios</h2>
          <div className="bg-gray-50 p-4 rounded-lg border border-gray-200">
            <div className="mb-6">
              <h3 className="text-md font-medium text-gray-700 mb-3">Provetes 7 dias</h3>
              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-200">
                  <thead className="bg-gray-100">
                    <tr>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Provete</th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Peso (kg)</th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Carga Rotura (KN)</th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Tensão Rotura (MPa)</th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Variação (%)</th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    <tr>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">Provete 1</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">8.2</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">450.5</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">20.0</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">-1.0</td>
                    </tr>
                    <tr>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">Provete 2</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">8.3</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">455.2</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">20.2</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">+1.0</td>
                    </tr>
                    <tr className="bg-blue-50">
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-700">Média</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-700">8.25</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-700">452.85</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-700">20.1</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-700">-</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
            
            <div>
              <h3 className="text-md font-medium text-gray-700 mb-3">Provetes 28 dias</h3>
              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-200">
                  <thead className="bg-gray-100">
                    <tr>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Provete</th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Peso (kg)</th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Carga Rotura (KN)</th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Tensão Rotura (MPa)</th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Variação (%)</th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    <tr>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">Provete 3</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">8.2</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">720.8</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">32.0</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">-1.2</td>
                    </tr>
                    <tr>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">Provete 4</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">8.4</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">735.5</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">32.7</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">+1.2</td>
                    </tr>
                    <tr className="bg-blue-50">
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-700">Média</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-700">8.3</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-700">728.15</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-700">32.35</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-700">-</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
        
        <div className="mb-8">
          <h2 className="text-lg font-semibold text-gray-700 mb-4">Avaliação de Conformidade</h2>
          <div className="bg-gray-50 p-4 rounded-lg border border-gray-200">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="bg-white p-4 rounded-lg border border-gray-200">
                <h3 className="text-md font-medium text-gray-700 mb-2">Critério 1</h3>
                <p className="text-sm text-gray-600 mb-2">Média dos resultados (fcm) ≥ fck + 1 MPa</p>
                <p className="text-sm mb-1"><span className="font-medium">Valor requerido:</span> 26.0 MPa</p>
                <p className="text-sm mb-1"><span className="font-medium">Valor obtido:</span> 32.35 MPa</p>
                <div className="mt-2 flex items-center">
                  <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">
                    CONFORME
                  </span>
                </div>
              </div>
              
              <div className="bg-white p-4 rounded-lg border border-gray-200">
                <h3 className="text-md font-medium text-gray-700 mb-2">Critério 2</h3>
                <p className="text-sm text-gray-600 mb-2">Resultado individual (fci) ≥ fck - 4 MPa</p>
                <p className="text-sm mb-1"><span className="font-medium">Valor requerido:</span> 21.0 MPa</p>
                <p className="text-sm mb-1"><span className="font-medium">Valor mínimo obtido:</span> 32.0 MPa</p>
                <div className="mt-2 flex items-center">
                  <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">
                    CONFORME
                  </span>
                </div>
              </div>
            </div>
            
            <div className="mt-4 p-4 bg-green-50 rounded-lg border border-green-200">
              <div className="flex items-center">
                <svg className="h-5 w-5 text-green-500 mr-2" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                  <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                </svg>
                <h3 className="text-md font-medium text-green-800">Avaliação Final: CONFORME</h3>
              </div>
              <p className="mt-1 text-sm text-green-700">
                O betão cumpre todos os critérios de conformidade estabelecidos na norma.
              </p>
            </div>
          </div>
        </div>
        
        <div className="flex justify-end space-x-3">
          <Link 
            href="/ensaios" 
            className="px-4 py-2 border border-gray-300 bg-white text-sm font-medium rounded-md text-gray-700 hover:bg-gray-50"
          >
            Voltar
          </Link>
          <Link 
            href="/ensaios/1/editar" 
            className="px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700"
          >
            Editar Ensaio
          </Link>
        </div>
      </div>
    </MainLayout>
  );
};

export default EnsaioDetalhePage;
