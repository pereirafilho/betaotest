import { FC } from 'react';
import Link from 'next/link';
import MainLayout from '../components/layout/MainLayout';

const EnsaiosPage: FC = () => {
  return (
    <MainLayout>
      <div className="bg-white shadow rounded-lg p-6">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-2xl font-bold text-gray-800">Ensaios</h1>
          <Link 
            href="/formulario" 
            className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700"
          >
            Novo Ensaio
          </Link>
        </div>
        
        <div className="bg-gray-50 p-4 rounded-lg border border-gray-200 mb-6">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Tipo de Betão
              </label>
              <select className="w-full border border-gray-300 rounded-md shadow-sm py-2 px-3">
                <option value="">Todos</option>
                <option value="1">C20 25.S4.XC2</option>
                <option value="2">C25 30.S4.XC2</option>
                <option value="3">C35 45.S4.XC3</option>
              </select>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Conformidade
              </label>
              <select className="w-full border border-gray-300 rounded-md shadow-sm py-2 px-3">
                <option value="">Todos</option>
                <option value="conforme">Conforme</option>
                <option value="nao-conforme">Não Conforme</option>
              </select>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Data Início
              </label>
              <input 
                type="date" 
                className="w-full border border-gray-300 rounded-md shadow-sm py-2 px-3"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Data Fim
              </label>
              <input 
                type="date" 
                className="w-full border border-gray-300 rounded-md shadow-sm py-2 px-3"
              />
            </div>
          </div>
          
          <div className="mt-4 flex justify-end">
            <button className="bg-gray-800 text-white py-2 px-4 rounded hover:bg-gray-900">
              Filtrar
            </button>
          </div>
        </div>
        
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Data Fabrico</th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Tipo Betão</th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Frente</th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Elemento</th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Média 7d</th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Média 28d</th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Ações</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              <tr>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">25/03/2025</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">C25 30.S4.XC2</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">Bloco A</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">Laje Piso 3</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">20.2 MPa</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">32.4 MPa</td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">Conforme</span>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                  <Link href="/ensaios/1" className="text-blue-600 hover:text-blue-900 mr-3">Ver</Link>
                  <Link href="/ensaios/1/editar" className="text-indigo-600 hover:text-indigo-900 mr-3">Editar</Link>
                </td>
              </tr>
              <tr>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">24/03/2025</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">C35 45.S4.XC3</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">Bloco B</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">Pilar P2</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">30.5 MPa</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">47.2 MPa</td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">Conforme</span>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                  <Link href="/ensaios/2" className="text-blue-600 hover:text-blue-900 mr-3">Ver</Link>
                  <Link href="/ensaios/2/editar" className="text-indigo-600 hover:text-indigo-900 mr-3">Editar</Link>
                </td>
              </tr>
              <tr>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">23/03/2025</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">C20 25.S4.XC2</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">Bloco C</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">Sapata S1</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">12.3 MPa</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">18.7 MPa</td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-red-100 text-red-800">Não Conforme</span>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                  <Link href="/ensaios/3" className="text-blue-600 hover:text-blue-900 mr-3">Ver</Link>
                  <Link href="/ensaios/3/editar" className="text-indigo-600 hover:text-indigo-900 mr-3">Editar</Link>
                </td>
              </tr>
              <tr>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">22/03/2025</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">C25 30.S4.XC2</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">Bloco A</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">Viga V3</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">19.8 MPa</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">31.8 MPa</td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">Conforme</span>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                  <Link href="/ensaios/4" className="text-blue-600 hover:text-blue-900 mr-3">Ver</Link>
                  <Link href="/ensaios/4/editar" className="text-indigo-600 hover:text-indigo-900 mr-3">Editar</Link>
                </td>
              </tr>
              <tr>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">21/03/2025</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">C25 30.S4.XC2</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">Bloco D</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">Laje Piso 2</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">19.2 MPa</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">30.5 MPa</td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">Conforme</span>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                  <Link href="/ensaios/5" className="text-blue-600 hover:text-blue-900 mr-3">Ver</Link>
                  <Link href="/ensaios/5/editar" className="text-indigo-600 hover:text-indigo-900 mr-3">Editar</Link>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
        
        <div className="mt-4 flex justify-between items-center">
          <div className="text-sm text-gray-700">
            Mostrando <span className="font-medium">1</span> a <span className="font-medium">5</span> de <span className="font-medium">157</span> resultados
          </div>
          <div className="flex space-x-2">
            <button className="px-3 py-1 border border-gray-300 bg-white text-sm font-medium rounded-md text-gray-700 hover:bg-gray-50 disabled:opacity-50" disabled>
              Anterior
            </button>
            <button className="px-3 py-1 border border-gray-300 bg-white text-sm font-medium rounded-md text-gray-700 hover:bg-gray-50">
              Próximo
            </button>
          </div>
        </div>
      </div>
    </MainLayout>
  );
};

export default EnsaiosPage;
