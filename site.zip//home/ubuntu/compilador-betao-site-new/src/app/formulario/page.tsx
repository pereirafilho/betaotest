import { FC } from 'react';
import Link from 'next/link';
import MainLayout from '../components/layout/MainLayout';

const FormularioPage: FC = () => {
  return (
    <MainLayout>
      <div className="bg-white shadow rounded-lg p-6">
        <h1 className="text-2xl font-bold text-gray-800 mb-6">Novo Ensaio</h1>
        
        <form>
          <div className="mb-6">
            <h2 className="text-lg font-semibold text-gray-700 mb-4">Informações Gerais</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Tipo de Betão *
                </label>
                <select 
                  className="w-full border border-gray-300 rounded-md shadow-sm py-2 px-3"
                  required
                >
                  <option value="">Selecione...</option>
                  <option value="1">C20 25.S4.XC2</option>
                  <option value="2">C25 30.S4.XC2</option>
                  <option value="3">C35 45.S4.XC3</option>
                </select>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Frente / Localização *
                </label>
                <input 
                  type="text" 
                  className="w-full border border-gray-300 rounded-md shadow-sm py-2 px-3"
                  placeholder="Ex: Bloco A"
                  required
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Elemento Betonado / Fase *
                </label>
                <input 
                  type="text" 
                  className="w-full border border-gray-300 rounded-md shadow-sm py-2 px-3"
                  placeholder="Ex: Laje Piso 3"
                  required
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  PAB *
                </label>
                <input 
                  type="text" 
                  className="w-full border border-gray-300 rounded-md shadow-sm py-2 px-3"
                  placeholder="Ex: PAB-2025-0123"
                  required
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  BRB *
                </label>
                <input 
                  type="text" 
                  className="w-full border border-gray-300 rounded-md shadow-sm py-2 px-3"
                  placeholder="Ex: BRB-2025-0456"
                  required
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Guia de Remessa *
                </label>
                <input 
                  type="text" 
                  className="w-full border border-gray-300 rounded-md shadow-sm py-2 px-3"
                  placeholder="Ex: GR-2025-0789"
                  required
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  M3 Betonado *
                </label>
                <input 
                  type="number" 
                  step="0.1"
                  className="w-full border border-gray-300 rounded-md shadow-sm py-2 px-3"
                  placeholder="Ex: 45.5"
                  required
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Data de Fabrico *
                </label>
                <input 
                  type="date" 
                  className="w-full border border-gray-300 rounded-md shadow-sm py-2 px-3"
                  required
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Abaixamento (mm) *
                </label>
                <input 
                  type="number" 
                  className="w-full border border-gray-300 rounded-md shadow-sm py-2 px-3"
                  placeholder="Ex: 120"
                  required
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Laboratório Ensaio *
                </label>
                <select 
                  className="w-full border border-gray-300 rounded-md shadow-sm py-2 px-3"
                  required
                >
                  <option value="">Selecione...</option>
                  <option value="BETOTESTE">BETOTESTE</option>
                  <option value="ECLAB">ECLAB</option>
                  <option value="SENQUAL">SENQUAL</option>
                  <option value="OUTRO">OUTRO</option>
                </select>
              </div>
              
              <div className="md:col-span-2 lg:col-span-3">
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Observações
                </label>
                <textarea 
                  className="w-full border border-gray-300 rounded-md shadow-sm py-2 px-3"
                  rows={3}
                  placeholder="Observações adicionais sobre o ensaio..."
                />
              </div>
            </div>
          </div>
          
          <div className="mb-6">
            <h2 className="text-lg font-semibold text-gray-700 mb-4">Provetes 7 dias</h2>
            <div className="bg-gray-50 p-4 rounded-lg border border-gray-200">
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Peso (kg) - Provete 1
                  </label>
                  <input 
                    type="number" 
                    step="0.1"
                    className="w-full border border-gray-300 rounded-md shadow-sm py-2 px-3"
                    placeholder="Ex: 8.2"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Carga Rotura (KN) - Provete 1
                  </label>
                  <input 
                    type="number" 
                    step="0.1"
                    className="w-full border border-gray-300 rounded-md shadow-sm py-2 px-3"
                    placeholder="Ex: 450.5"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Tensão Rotura (MPa) - Provete 1
                  </label>
                  <input 
                    type="number" 
                    step="0.1"
                    className="w-full border border-gray-300 rounded-md shadow-sm py-2 px-3"
                    placeholder="Calculado automaticamente"
                    readOnly
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Variação (%) - Provete 1
                  </label>
                  <input 
                    type="number" 
                    step="0.1"
                    className="w-full border border-gray-300 rounded-md shadow-sm py-2 px-3"
                    placeholder="Calculado automaticamente"
                    readOnly
                  />
                </div>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Peso (kg) - Provete 2
                  </label>
                  <input 
                    type="number" 
                    step="0.1"
                    className="w-full border border-gray-300 rounded-md shadow-sm py-2 px-3"
                    placeholder="Ex: 8.3"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Carga Rotura (KN) - Provete 2
                  </label>
                  <input 
                    type="number" 
                    step="0.1"
                    className="w-full border border-gray-300 rounded-md shadow-sm py-2 px-3"
                    placeholder="Ex: 455.2"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Tensão Rotura (MPa) - Provete 2
                  </label>
                  <input 
                    type="number" 
                    step="0.1"
                    className="w-full border border-gray-300 rounded-md shadow-sm py-2 px-3"
                    placeholder="Calculado automaticamente"
                    readOnly
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Variação (%) - Provete 2
                  </label>
                  <input 
                    type="number" 
                    step="0.1"
                    className="w-full border border-gray-300 rounded-md shadow-sm py-2 px-3"
                    placeholder="Calculado automaticamente"
                    readOnly
                  />
                </div>
              </div>
            </div>
          </div>
          
          <div className="mb-6">
            <h2 className="text-lg font-semibold text-gray-700 mb-4">Provetes 28 dias</h2>
            <div className="bg-gray-50 p-4 rounded-lg border border-gray-200">
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Peso (kg) - Provete 3
                  </label>
                  <input 
                    type="number" 
                    step="0.1"
                    className="w-full border border-gray-300 rounded-md shadow-sm py-2 px-3"
                    placeholder="Ex: 8.2"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Carga Rotura (KN) - Provete 3
                  </label>
                  <input 
                    type="number" 
                    step="0.1"
                    className="w-full border border-gray-300 rounded-md shadow-sm py-2 px-3"
                    placeholder="Ex: 720.8"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Tensão Rotura (MPa) - Provete 3
                  </label>
                  <input 
                    type="number" 
                    step="0.1"
                    className="w-full border border-gray-300 rounded-md shadow-sm py-2 px-3"
                    placeholder="Calculado automaticamente"
                    readOnly
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Variação (%) - Provete 3
                  </label>
                  <input 
                    type="number" 
                    step="0.1"
                    className="w-full border border-gray-300 rounded-md shadow-sm py-2 px-3"
                    placeholder="Calculado automaticamente"
                    readOnly
                  />
                </div>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Peso (kg) - Provete 4
                  </label>
                  <input 
                    type="number" 
                    step="0.1"
                    className="w-full border border-gray-300 rounded-md shadow-sm py-2 px-3"
                    placeholder="Ex: 8.4"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Carga Rotura (KN) - Provete 4
                  </label>
                  <input 
                    type="number" 
                    step="0.1"
                    className="w-full border border-gray-300 rounded-md shadow-sm py-2 px-3"
                    placeholder="Ex: 735.5"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Tensão Rotura (MPa) - Provete 4
                  </label>
                  <input 
                    type="number" 
                    step="0.1"
                    className="w-full border border-gray-300 rounded-md shadow-sm py-2 px-3"
                    placeholder="Calculado automaticamente"
                    readOnly
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Variação (%) - Provete 4
                  </label>
                  <input 
                    type="number" 
                    step="0.1"
                    className="w-full border border-gray-300 rounded-md shadow-sm py-2 px-3"
                    placeholder="Calculado automaticamente"
                    readOnly
                  />
                </div>
              </div>
            </div>
          </div>
          
          <div className="flex justify-end space-x-3">
            <Link 
              href="/ensaios" 
              className="px-4 py-2 border border-gray-300 bg-white text-sm font-medium rounded-md text-gray-700 hover:bg-gray-50"
            >
              Cancelar
            </Link>
            <button 
              type="submit"
              className="px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700"
            >
              Salvar Ensaio
            </button>
          </div>
        </form>
      </div>
    </MainLayout>
  );
};

export default FormularioPage;
