import { FC } from 'react';
import MainLayout from '../components/layout/MainLayout';

const RelatoriosPage: FC = () => {
  return (
    <MainLayout>
      <div className="bg-white shadow rounded-lg p-6">
        <h1 className="text-2xl font-bold text-gray-800 mb-6">Relatórios</h1>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
            <h2 className="text-lg font-semibold text-blue-800 mb-3">Relatório Completo</h2>
            <p className="text-gray-600 mb-4">
              Exporta todos os dados de ensaios com informações detalhadas.
            </p>
            <button className="w-full bg-blue-600 text-white py-2 px-4 rounded hover:bg-blue-700">
              Exportar CSV
            </button>
          </div>
          
          <div className="bg-green-50 p-4 rounded-lg border border-green-200">
            <h2 className="text-lg font-semibold text-green-800 mb-3">Relatório Resumido</h2>
            <p className="text-gray-600 mb-4">
              Resumo estatístico por tipo de betão com médias e taxas de conformidade.
            </p>
            <button className="w-full bg-green-600 text-white py-2 px-4 rounded hover:bg-green-700">
              Exportar CSV
            </button>
          </div>
          
          <div className="bg-purple-50 p-4 rounded-lg border border-purple-200">
            <h2 className="text-lg font-semibold text-purple-800 mb-3">Relatório de Provetes</h2>
            <p className="text-gray-600 mb-4">
              Dados detalhados de todos os provetes com resultados de ensaios.
            </p>
            <button className="w-full bg-purple-600 text-white py-2 px-4 rounded hover:bg-purple-700">
              Exportar CSV
            </button>
          </div>
        </div>
        
        <div className="mt-8">
          <h2 className="text-xl font-semibold text-gray-800 mb-4">Filtros de Relatório</h2>
          
          <div className="bg-gray-50 p-4 rounded-lg border border-gray-200">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Tipo de Betão
                </label>
                <select className="w-full border border-gray-300 rounded-md shadow-sm py-2 px-3">
                  <option value="">Todos</option>
                  <option value="1">C20 25.S4.XC2</option>
                  <option value="2">C25 30.S4.XC2</option>
                  <option value="3">C35 45.S4.XC3</option>
                </select>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Data Início
                </label>
                <input 
                  type="date" 
                  className="w-full border border-gray-300 rounded-md shadow-sm py-2 px-3"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Data Fim
                </label>
                <input 
                  type="date" 
                  className="w-full border border-gray-300 rounded-md shadow-sm py-2 px-3"
                />
              </div>
            </div>
            
            <div className="mt-4 flex justify-end">
              <button className="bg-gray-800 text-white py-2 px-4 rounded hover:bg-gray-900">
                Aplicar Filtros
              </button>
            </div>
          </div>
        </div>
        
        <div className="mt-8">
          <h2 className="text-xl font-semibold text-gray-800 mb-4">Estatísticas Gerais</h2>
          
          <div className="bg-gray-50 p-4 rounded-lg border border-gray-200">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="bg-white p-3 rounded-md border border-gray-200">
                <p className="text-sm font-medium text-gray-500">Total de Ensaios</p>
                <p className="mt-1 text-2xl font-semibold text-gray-900">157</p>
              </div>
              
              <div className="bg-white p-3 rounded-md border border-gray-200">
                <p className="text-sm font-medium text-gray-500">Ensaios Conformes</p>
                <p className="mt-1 text-2xl font-semibold text-green-600">142</p>
              </div>
              
              <div className="bg-white p-3 rounded-md border border-gray-200">
                <p className="text-sm font-medium text-gray-500">Ensaios Não Conformes</p>
                <p className="mt-1 text-2xl font-semibold text-red-600">15</p>
              </div>
              
              <div className="bg-white p-3 rounded-md border border-gray-200">
                <p className="text-sm font-medium text-gray-500">Taxa de Conformidade</p>
                <p className="mt-1 text-2xl font-semibold text-blue-600">90.4%</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </MainLayout>
  );
};

export default RelatoriosPage;
