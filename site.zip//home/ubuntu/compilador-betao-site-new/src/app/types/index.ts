export interface Usuario {
  id: string;
  nome: string;
  email: string;
  cargo: string;
  dataCriacao: Date;
}

export interface TipoBetao {
  id: string;
  codigo: string;
  descricao: string;
}

export interface Provete {
  numero: number;
  idade: number;
  dataEnsaio: Date;
  peso: number;
  cargaRotura: number;
  tensaoRotura: number;
  variacao: number;
}

export interface Ensaio {
  id: string;
  tipoBetaoId: string;
  tipoBetao?: TipoBetao;
  frente: string;
  elementoBetonado: string;
  pab: string;
  brb: string;
  guiaRemessa: string;
  m3Betonado: number;
  dataFabrico: Date;
  abaixamento: number;
  laboratorio: string;
  observacoes: string;
  provetes: Provete[];
  mediaProvetes: number;
  conformidade: boolean;
  criadoPor: string;
  dataCriacao: Date;
}
